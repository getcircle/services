

class ParseError(Exception):
    pass
